# iBeacon 蓝牙签到模拟器

使用 C++ 实现的 iBeacon 模拟器，用于蓝牙远程签到。

## 功能特性

- 模拟 iBeacon 信号广播
- 支持自定义 UUID、Major、Minor 参数
- 自动化启动和停止流程
- 支持多种 Linux 发行版

## 系统要求

- **操作系统**: Linux (Ubuntu/Debian/CentOS/Fedora/Arch)
- **硬件**: 支持 BLE (蓝牙 4.0+) 的蓝牙适配器
- **权限**: 需要 root 权限运行

## 快速开始

### 方法一：使用预编译版本（推荐）

1. **解压文件**
```bash
tar -xzf ibeacon-simulator.tar.gz
cd ibeacon-simulator
```

2. **启动程序**
```bash
sudo ./start.sh
```

3. **停止程序**
```
按 Ctrl+C 或在另一个终端执行:
sudo ./stop.sh
```

### 方法二：从源码编译

1. **解压源码**
```bash
tar -xzf ibeacon-simulator.tar.gz
cd ibeacon-simulator
```

2. **安装依赖**
```bash
sudo ./install.sh
```

3. **编译程序**
```bash
./build.sh
```

4. **启动程序**
```bash
sudo ./start.sh
```

## 详细说明

### 目录结构

```
ibeacon-simulator/
├── main.cpp              # 源代码
├── beacon_simulator      # 可执行文件（编译后生成）
├── install.sh           # 依赖安装脚本
├── build.sh             # 编译脚本
├── start.sh             # 启动脚本
├── stop.sh              # 停止脚本
└── README.md            # 使用说明
```

### 脚本说明

#### install.sh - 依赖安装
自动检测 Linux 发行版并安装所需依赖：
- g++ 编译器
- libbluetooth-dev 蓝牙开发库
- bluez 蓝牙协议栈

支持的发行版：
- Ubuntu / Debian
- CentOS / RHEL / Rocky / AlmaLinux
- Fedora
- Arch Linux / Manjaro

#### build.sh - 编译程序
从源代码编译生成可执行文件 `beacon_simulator`

#### start.sh - 启动程序
自动执行以下步骤：
1. 停止已运行的实例
2. 停止系统蓝牙服务
3. 手动启动蓝牙设备
4. 启动 iBeacon 模拟器
5. 退出后自动恢复蓝牙服务

#### stop.sh - 停止程序
停止 iBeacon 模拟器并恢复系统蓝牙服务

## 配置参数

当前配置的 iBeacon 参数（在 main.cpp 中）：

```cpp
UUID:  FDA50693-A4E2-4FB1-AFCF-C6EB07647825
Major: 10199 (0x27D7)
Minor: 42474 (0xA5EA)
TX Power: -59 dBm
```

### 修改参数

如需修改参数，编辑 `main.cpp` 文件第 60-79 行，然后重新编译：

```bash
nano main.cpp          # 或使用其他编辑器
./build.sh             # 重新编译
sudo ./start.sh        # 启动
```

## 测试验证

使用手机 App 扫描 iBeacon 信号：

### Android
- **Brightbeacon**（推荐）
- Beacon Scanner
- nRF Connect

### iOS
- Locate Beacon
- iBeacon Detector

预期扫描结果：
- UUID: FDA50693-A4E2-4FB1-AFCF-C6EB07647825
- Major: 10199
- Minor: 42474
- 信号强度: 根据距离变化

## 常见问题

### Q1: 提示"错误: 未找到蓝牙适配器"
**原因**:
- 蓝牙适配器未插入
- 驱动未正确安装
- 虚拟机 USB 直通未配置

**解决**:
```bash
# 检查蓝牙设备
hciconfig -a

# 如果是虚拟机，需要配置 USB 直通
```

### Q2: 提示"错误: 无法启动广播"
**原因**: 蓝牙服务占用设备

**解决**:
```bash
# 手动停止蓝牙服务
sudo systemctl stop bluetooth

# 重新启动
sudo ./start.sh
```

### Q3: 手机扫描不到信号
**检查步骤**:
1. 确认程序显示"模拟成功！正在广播目标信号..."
2. 检查蓝牙设备状态: `hciconfig hci0`
3. 重启手机蓝牙
4. 确认手机支持 BLE (蓝牙 4.0+)

### Q4: 虚拟机中无法使用
**VMware/VirtualBox 配置**:
1. 关闭虚拟机
2. 添加 USB 控制器
3. 启用 USB 3.0
4. 将蓝牙适配器连接到虚拟机
5. 启动虚拟机并验证: `lsusb`

## 注意事项

1. **必须使用 sudo 运行**: 操作蓝牙硬件需要 root 权限
2. **蓝牙服务冲突**: 程序运行时会停止系统蓝牙服务
3. **退出恢复**: 按 Ctrl+C 退出后会自动恢复系统蓝牙
4. **仅支持 Linux**: 依赖 BlueZ 蓝牙栈，不支持 Windows/macOS

## 技术细节

- **协议**: iBeacon (Apple 标准)
- **蓝牙版本**: BLE (Bluetooth Low Energy 4.0+)
- **广播类型**: ADV_NONCONN_IND (不可连接)
- **广播间隔**: 1.28 秒
- **广播信道**: 37, 38, 39 (全部3个)

## 许可证

本项目仅供学习和研究使用。

## 版本历史

**v1.0** (2025-11-30)
- 初始版本
- 支持基本的 iBeacon 模拟功能
- 自动化脚本
- 多发行版支持

## 联系方式

如有问题或建议，请提交 Issue。
